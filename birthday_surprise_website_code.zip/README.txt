Birthday Surprise Website

Password: 2311

Included:
- index.html
- assets/ (the selected password, birthday cover, and home screen designs)
- photos/ (the 7 original photos)
- kitten images

How to use:
1. Extract this ZIP.
2. Upload the contents inside the folder to the root of your GitHub repository.
3. Make sure index.html is at the repository root and keep the assets and photos folders.
4. Enable GitHub Pages from Settings > Pages if it is not already enabled.

The website flow:
Password -> Birthday cover -> tap the kitten -> Message or Photos.
